import pygame
from time import sleep
from random import randrange

pygame.init()
